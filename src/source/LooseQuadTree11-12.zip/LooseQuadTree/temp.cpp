#include <iostream> 
#include <ctime> 
#include <cstdlib>

#include "tName.h"
#include "PriorityQueue.h"

using namespace std;
int main(int argc, char *argv[])
 {	
	PriorityQueue *queue = new PriorityQueue();	
	Rectangle * rect1 = new Rectangle("Rect1",1,2,3,4);	

	cout << "Test" << endl;
	
//    srand((unsigned)time(0)); 
//    int random_integer; 
//    int lowest=20, highest=70; 
//    int range=(highest-lowest)+1; 
//    for(int index=0; index<200; index++){ 
//    	random_integer = (rand()%10)+1; 
//        Rectangle * rect1 = new Rectangle("Rect1",1,2,3,4);	
//        queue->Enqueue(rect1,random_integer,(rand()%4)+1 );
//    } 
//    
//    cout << endl;
//	while(!queue->IsEmpty()){
//		CompareField temp = queue->Dequeue();
//		cout << temp.distance << " " <<temp.quadrant << endl;
//	}
	
   return 0;
 }
