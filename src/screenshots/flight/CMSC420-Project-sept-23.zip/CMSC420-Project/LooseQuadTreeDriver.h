#ifndef LOOSEQUADTREEDRIVER_H
#define LOOSEQUADTREEDRIVER_H
#include <iostream>
#include <math.h>
#include <string>
#include "LooseQuadTree.h"
#include "drawing_c.h"
#include "tName.h"

using namespace std;

class LooseQuadTreeDriver {
	public:
		LooseQuadTreeDriver();
		void initLooseQuadTree();
		void initRectTree();
		void traceOn();
		void traceOff();

		tName** parse_command(tName *input);
		bool isFloatingPointNumber(tName *s);
		
		void INIT_QUADTREE(int width, double p);
		void DISPLAY();
		void LIST_RECTANGLES();
		void CREATE_RECTANGLE(string name,int cx,int cy,int lx, int ly);
		void INSERT(string n);
		void MOVE(string name, int cx, int cy);
		void SEARCH_POINT(int px, int py);
		void DELETE_RECTANGLE(string n);
		void DELETE_POINT(int px, int py);
		void REGION_SEARCH(string n);
		LooseQuadTree looseQuadTree;
		bNode *rectTree;
	private:
		bool trace;
		
};
#endif
