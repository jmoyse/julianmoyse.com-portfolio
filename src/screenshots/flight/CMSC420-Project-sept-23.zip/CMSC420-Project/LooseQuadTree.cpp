#include "LooseQuadTree.h"
using namespace std;

LooseQuadTree::LooseQuadTree() {
    looseQuadRoot = NULL;
    trace = false;
}
LooseQuadTree::LooseQuadTree(string name, int centerX, int centerY, int lengthX, int lengthY, float expansion) {
    looseQuadRoot = NULL;
    looseQuadRoot = new cNode();
    World = Rectangle(name,centerX,centerY,lengthX,lengthY);
    p = expansion;
    trace = false;
}
void LooseQuadTree::traceOn() {
    trace = true;
    looseQuadRoot->trace = true;
}
void LooseQuadTree::traceOff() {
    trace = false;
    looseQuadRoot->trace = false;
}

void LooseQuadTree::AddRectangle(Rectangle *r) {
    looseQuadRoot->insertcNodeRectangle(r,looseQuadRoot,World.getLengthX(),World.getLengthY(),World.getCenterX(),World.getCenterY(), 0, p);
}




void LooseQuadTree::removeNode(Rectangle* rect, cNode **tree, int worldX, int ly, int cx, int cy, int position, bNode ** list) {
}

bNode * LooseQuadTree::deletePoint(int x, int y) {
    bNode * value = new bNode();
    return value;
}


void LooseQuadTree::searchPoint(int findX, int findY, cNode *tree, int worldX, int worldY, int CenterX, int CenterY, int position, bNode ** list) {
    int newX=0;
    int newY=0;
    int quadrant = 0;

    if (tree!=NULL) {
        if (trace == true)
            cout << position << " " ;
        if (findX < CenterX) {
            if (findY < CenterY) { // SW NODE
                newX = CenterX-(worldX/4);
                newY = CenterY-(worldY/4);
                quadrant = tree->SW;
            } else { // NW NODE
                newX = CenterX-(worldX/4);
                newY = CenterY+(worldY/4);
                quadrant = tree->NW;
            }
        } else {
            if(findY < CenterY) { // SE NODE
                newX = CenterX+(worldX/4);
                newY = CenterY-(worldY/4);
                quadrant = tree->SE;
            } else {  // NE NODE
                newX = CenterX+(worldX/4);
                newY = CenterY+(worldY/4);
                quadrant = tree->NE;
            }
        }
        if (tree->binSon!=NULL && tree->binSon->length > 0) {
            for (int i =0; i< tree->binSon->length; i++) {
                if ((*list)->length == 0)
                    (*list) = new bNode(tree->binSon->getNode(i));
                else
                    (*list)->insertNode(tree->binSon->getNode(i));
            }
        }
        searchPoint(findX,findY, tree->spcSon[quadrant], newX, newY, CenterX/2, CenterY/2, 4*position+(quadrant+1), &(*list));
        return;
  }
    if (trace = true)
        cout << endl;
}

bNode * LooseQuadTree::regionSearch(string n) {
    bNode * value = new bNode();
    return value;
}

LooseQuadTree::~LooseQuadTree() {}
