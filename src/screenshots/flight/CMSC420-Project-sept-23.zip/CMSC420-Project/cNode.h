#ifndef CNODE_H
#define CNODE_H

#define NDIR_2D 4
#include "bNode.h"


class cNode {
	public:
		typedef enum {NW,NE,SW,SE} quadrant;
		cNode();
		cNode(int quadrant, Rectangle *r);
			
		~cNode();
		void drawQuadrants(cNode *quadTreeNode,int cx,int cy,int lx,int ly, int position);
		void printQuadrants(cNode *quadTreeNode);
		void printQuadrants(cNode *quadTreeNode, int depth);
		void insertRectangle(int quadrant, Rectangle *r);
		void deleteRectangle(cNode **quadTreeNode, Rectangle * rect, int cx, int cy, int lx, int ly, int position, bNode ** list);
		void deletePoint(cNode **quadTreeNode,int findX, int findY, int cx, int cy, int lx, int ly, int position, bNode ** list);
		void insertcNodeRectangle(Rectangle *r, cNode *tree, int worldX, int worldY, int centerX, int centerY, int position, int p);
		void moveInsert(Rectangle *r, cNode **tree, int worldX, int worldY, int centerX, int centerY, int position, int p);
		void moveRectangle(cNode **quadTreeNode, Rectangle * rect, int offsetx, int offsety, int cx, int cy, int lx, int ly, float expansion,  int position,  bNode ** list);
		void regionNodeSearch(cNode **quadTreeNode, Rectangle * rect, int cx, int cy, int lx, int ly, int position, bNode ** list);
		Rectangle * findRectangle(cNode *quadTreeNode, string name);
		void insert(Rectangle *r);
		void searchPoint(cNode *quadTreeNode, int px, int py, int position,  bNode ** list);
		void traceOn();
		void traceOff();
		
		cNode* getNW();
		cNode* getSW();
		cNode* getNE();
		cNode* getSE();		
		bool trace;
		cNode *spcSon[NDIR_2D];
		bNode *binSon;	
};
#endif
