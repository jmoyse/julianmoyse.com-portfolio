#include "cNode.h"
#include "drawing_c.h"
using namespace std;


cNode::cNode() {
    spcSon[NW] = NULL;
    spcSon[NE] = NULL;
    spcSon[SW] = NULL;
    spcSon[SE] = NULL;
    binSon = NULL;
    binSon = new bNode();
    trace = false;
}
cNode::cNode(int quadrant, Rectangle *r) {
    spcSon[NW] = NULL;
    spcSon[NE] = NULL;
    spcSon[SW] = NULL;
    spcSon[SE] = NULL;
    spcSon[quadrant] = new cNode();
    binSon = new bNode();
    spcSon[quadrant]->binSon = new bNode(r);
}

void cNode::insert(Rectangle *r) {
    if (binSon->length == 0) {
        binSon = new bNode(r);
    } else {
        binSon->insertNode(r);
    }
}
void cNode::traceOn() {
    trace = true;
}
void cNode::traceOff() {
    trace = false;
}

void cNode::insertRectangle(int quadrant, Rectangle *r) {
    if (spcSon[quadrant] == NULL) {
        spcSon[quadrant] = new cNode();
    }

    if (spcSon[quadrant]->binSon->length == 0) {
        spcSon[quadrant]->binSon = new bNode(r);
    } else {
        spcSon[quadrant]->binSon->insertNode(r);
    }
}

void cNode::printQuadrants(cNode *quadTreeNode) {
    if(quadTreeNode != NULL) {
        printQuadrants(quadTreeNode->spcSon[NW]);
        printQuadrants(quadTreeNode->spcSon[NE]);
        quadTreeNode->binSon->printNodes();
        cout << endl;
        printQuadrants(quadTreeNode->spcSon[SW]);
        printQuadrants(quadTreeNode->spcSon[SE]);
    }
}
void cNode::drawQuadrants(cNode *quadTreeNode,int cx,int cy,int lx,int ly, int position) {
    if(quadTreeNode != NULL) {
        if (quadTreeNode->binSon!= NULL) {
            for (int i = 0; i<quadTreeNode->binSon->length; i++) {
                int minX = quadTreeNode->binSon->getNode(i)->getCenterX() - quadTreeNode->binSon->getNode(i)->getLengthX()/2;
                int minY = quadTreeNode->binSon->getNode(i)->getCenterY() - quadTreeNode->binSon->getNode(i)->getLengthY()/2;
                int maxX = quadTreeNode->binSon->getNode(i)->getCenterX() + quadTreeNode->binSon->getNode(i)->getLengthX()/2;
                int maxY = quadTreeNode->binSon->getNode(i)->getCenterY() + quadTreeNode->binSon->getNode(i)->getLengthY()/2;

                SetLineDash(1,1);
                DrawRect(minX,minY,maxX,maxY);

                char * temp;
                temp = new char[quadTreeNode->binSon->getNode(i)->getName().length() + 1];
                strcpy(temp, quadTreeNode->binSon->getNode(i)->getName().c_str());

                DrawName(temp, minX,minY);
            }
        }
        if (quadTreeNode->spcSon[NW] == NULL && quadTreeNode->spcSon[NE] == NULL && quadTreeNode->spcSon[SW] == NULL && quadTreeNode->spcSon[SE] == NULL)
            return;

        SetLineDash(3,2);
        DrawLine(cx-(lx/2),cy,cx+(lx/2),cy);
        SetLineDash(3,2);
        DrawLine(cx,cy-(ly/2),cx,cy+(ly/2));

        drawQuadrants(quadTreeNode->spcSon[NW], cx-(lx/4), cy+(ly/4), lx/2,ly/2, 4*position+1);
        drawQuadrants(quadTreeNode->spcSon[NE], cx+(lx/4), cy+(ly/4), lx/2,ly/2, 4*position+2);
        drawQuadrants(quadTreeNode->spcSon[SW], cx-(lx/4), cy-(ly/4), lx/2,ly/2, 4*position+3);
        drawQuadrants(quadTreeNode->spcSon[SE], cx+(lx/4), cy-(ly/4), lx/2,ly/2, 4*position+4);
    }
}

//
//void cNode::printQuadrants(cNode *quadTreeNode, int depth) {
//    if(quadTreeNode != NULL) {
//        for (int i=0; i<depth; i++) {
//            cout << "  ";
//        }
//        quadTreeNode->binSon->printNodes();
//        cout << endl;
//        printQuadrants(quadTreeNode->spcSon[NW], depth+1);
//        printQuadrants(quadTreeNode->spcSon[NE], depth+1);
//        printQuadrants(quadTreeNode->spcSon[SW], depth+1);
//        printQuadrants(quadTreeNode->spcSon[SE], depth+1);
//    }
//}

//Rectangle * cNode::findRectangle(cNode *quadTreeNode, string name) {
//    Rectangle * NWrect = NULL;
//    Rectangle * NErect = NULL;
//    Rectangle * SWrect = NULL;
//
//    Rectangle * SErect = NULL;
//    if(quadTreeNode != NULL) {
//        if (quadTreeNode->binSon != NULL) {
//            bNode *temp = quadTreeNode->binSon->searchNode(name);
//            if (temp != NULL) {
//                return  temp->Rect;
//            }
//        }
//        Rectangle * NWrect = findRectangle(quadTreeNode->spcSon[NW], name);
//        if (NWrect!= NULL)
//            return NWrect;
//        Rectangle * NErect = findRectangle(quadTreeNode->spcSon[NE], name);
//        if (NErect!= NULL)
//            return NErect;
//        Rectangle * SWrect = findRectangle(quadTreeNode->spcSon[SW], name);
//        if (SWrect!= NULL)
//            return SWrect;
//        Rectangle * SErect = findRectangle(quadTreeNode->spcSon[SE], name);
//        if (SErect!= NULL)
//            return SErect;
//        return NULL;
//    }
//    return NULL;
//}

//
//void  cNode::searchPoint(cNode *quadTreeNode, int px, int py, int position,  bNode ** list) {
//    if(quadTreeNode != NULL) {
//        if (trace == true)
//            cout << position << " ";
//
//        if (quadTreeNode->binSon != NULL && quadTreeNode->binSon->length > 0) {
//            for (int i=0; i<quadTreeNode->binSon->length; i++) {
//                Rectangle *node = quadTreeNode->binSon->getNode(i);
//                int RectMaxX = node->getCenterX()+(node->getLengthX()/2);
//                int RectMinX = node->getCenterX()-(node->getLengthX()/2);
//                int RectMaxY = node->getCenterY()+(node->getLengthY()/2);
//                int RectMinY = node->getCenterY()-(node->getLengthY()/2);
//                if (px>RectMinX && px<RectMaxX) {
//                    if (py>RectMinY && py<RectMaxY) {
//                        if ((*list)->length == 0)
//                            (*list) = new bNode(node);
//                        else
//                            (*list)->insertNode(node);
//                    }
//                }
//            }
//        }
//        searchPoint(quadTreeNode->spcSon[NW], px, py, 4*position+1,&(*list));
//        searchPoint(quadTreeNode->spcSon[NE], px, py, 4*position+2, &(*list));
//        searchPoint(quadTreeNode->spcSon[SW], px, py, 4*position+3,&(*list));
//        searchPoint(quadTreeNode->spcSon[SE], px,	 py, 4*position+4,&(*list));
//    }
//}

void cNode::moveRectangle(cNode **quadTreeNode, Rectangle * rect, int offsetx, int offsety, int cx, int cy, int lx, int ly, float expansion, int position, bNode ** list) {
    int newX=0;
    int newY=0;
    int quadrant = 0;
    if((*quadTreeNode) != NULL) {
        if (trace == true)
            cout << position << " ";
        if ((*quadTreeNode)->binSon != NULL) {
            bNode *temp = (*quadTreeNode)->binSon->searchNode(rect->getName());
            if (temp != NULL) {
                if ((*quadTreeNode)->binSon->length == 1) {
                    (*quadTreeNode)->binSon = new bNode();
                } else {
                    (*quadTreeNode)->binSon->removeNode(temp->Rect);
                }
            }
        }

        if (rect->getCenterX() < cx) {
            if (rect->getCenterY() < cy) {
                newX = cx-(lx/4);
                newY = cy-(ly/4);
                quadrant = SW;
                moveRectangle(&(*quadTreeNode)->spcSon[SW], rect, offsetx, offsety, newX,newY,lx/2,ly/2, expansion, 4*position+1,&(*list));
            } else {
                newX = cx-(lx/4);
                newY = cy+(ly/4);
                quadrant =NW;
                moveRectangle(&(*quadTreeNode)->spcSon[NW], rect, offsetx, offsety, newX,newY,lx/2,ly/2, expansion,4*position+3,&(*list));
            }
        } else {
            if(rect->getCenterY() < cy) {
                newX = cx+(lx/4);
                newY = cy-(ly/4);
                quadrant = SE;
                moveRectangle(&(*quadTreeNode)->spcSon[SE], rect, offsetx, offsety, newX,newY,lx/2,ly/2, expansion,4*position+2,&(*list));
            } else {
                newX = cx+(lx/4);
                newY = cy+(ly/4);
                quadrant = NE;
                moveRectangle(&(*quadTreeNode)->spcSon[NE], rect, offsetx, offsety, newX,newY,lx/2,ly/2, expansion,4*position+4,&(*list));
            }
        }
        
		int rRight = rect->getCenterX()+(rect->getLengthX()/2)+offsetx;
		int rLeft = rect->getCenterX()-(rect->getLengthX()/2)+offsetx;
		int rTop = rect->getCenterY()+(rect->getLengthY()/2)+offsety;
		int rBottom = rect->getCenterY()-(rect->getLengthY()/2)+offsety;
			
		int wRight = cx+(lx/2)*(1+expansion);
		int wLeft = cx-(lx/2)*(1+expansion);
		int wTop = cy+(ly/2)*(1+expansion);
		int wBottom = cy-(ly/2)*(1+expansion);
		
		if (rRight <= wRight && rLeft>=wLeft && rTop<=wTop && rBottom >= wBottom && (*list)->length == 0){
			rect->setCenter((rect->getCenterX())+offsetx, (rect->getCenterY())+offsety);
			insertcNodeRectangle(rect,*quadTreeNode,lx,ly,cx,cy,position, expansion);			
		    if ((*list)->length == 0)
                (*list) = new bNode(rect);
            else
                (*list)->insertNode(rect);
			return;
		} 
		
        if ((*quadTreeNode)->spcSon[NW] == NULL && (*quadTreeNode)->spcSon[NE] == NULL && (*quadTreeNode)->spcSon[SW] == NULL && (*quadTreeNode)->spcSon[SE] == NULL && ((*quadTreeNode)->binSon == NULL || (*quadTreeNode)->binSon->length == 0) && (*quadTreeNode)!=this) {
            (*quadTreeNode) = NULL;
        }
        
    }
}

void cNode::deleteRectangle(cNode **quadTreeNode, Rectangle * rect, int cx, int cy, int lx, int ly, int position,  bNode ** list) {
    int newX=0;
    int newY=0;
    int quadrant = 0;
    if((*quadTreeNode) != NULL) {
        if (trace == true)
            cout << position << " ";
        if ((*quadTreeNode)->binSon != NULL) {
            bNode *temp = (*quadTreeNode)->binSon->searchNode(rect->getName());
            if (temp != NULL) {
                if ((*quadTreeNode)->binSon->length == 1) {
                    (*quadTreeNode)->binSon = new bNode();
                } else {
                    (*quadTreeNode)->binSon->removeNode(temp->Rect);
                }
                if ((*list)->length == 0)
                    (*list) = new bNode(rect);
                else
                    (*list)->insertNode(rect);
            }
        }

        if (rect->getCenterX() < cx) {
            if (rect->getCenterY() < cy) {
                newX = cx-(lx/4);
                newY = cy-(ly/4);
                quadrant = SW;
                deleteRectangle(&(*quadTreeNode)->spcSon[SW], rect, newX,newY,lx/2,ly/2, 4*position+1,&(*list));
            } else {
                newX = cx-(lx/4);
                newY = cy+(ly/4);
                quadrant =NW;
                deleteRectangle(&(*quadTreeNode)->spcSon[NW], rect, newX,newY,lx/2,ly/2,4*position+3,&(*list));
            }
        } else {
            if(rect->getCenterY() < cy) {
                newX = cx+(lx/4);
                newY = cy-(ly/4);
                quadrant = SE;
                deleteRectangle(&(*quadTreeNode)->spcSon[SE], rect,newX,newY,lx/2,ly/2,4*position+2,&(*list));
            } else {
                newX = cx+(lx/4);
                newY = cy+(ly/4);
                quadrant = NE;
                deleteRectangle(&(*quadTreeNode)->spcSon[NE], rect,newX,newY,lx/2,ly/2,4*position+4,&(*list));
            }
        }
        if ((*quadTreeNode)->spcSon[NW] == NULL && (*quadTreeNode)->spcSon[NE] == NULL && (*quadTreeNode)->spcSon[SW] == NULL && (*quadTreeNode)->spcSon[SE] == NULL && ((*quadTreeNode)->binSon == NULL || (*quadTreeNode)->binSon->length == 0) && (*quadTreeNode)!=this) {
            (*quadTreeNode) = NULL;
        }
    }
}

void cNode::insertcNodeRectangle(Rectangle *r, cNode *tree, int worldX, int worldY, int centerX, int centerY, int position, int p) {
    int rRight = r->getCenterX()+(r->getLengthX()/2);
    int rLeft = r->getCenterX()-(r->getLengthX()/2);
    int rTop = r->getCenterY()+(r->getLengthY()/2);
    int rBottom = r->getCenterY()-(r->getLengthY()/2);

    int wRight = centerX+(worldX/2)*(1+p);
    int wLeft = centerX-(worldX/2)*(1+p);
    int wTop = centerY+(worldY/2)*(1+p);
    int wBottom = centerY-(worldY/2)*(1+p);


    int newX = (worldX/2*(1+p))/2;
    int newY = (worldY/2*(1+p))/2;

    if (trace == true)
        cout << position << " " ;
		
    if (r->getCenterX() >= centerX && rLeft >= ((centerX+(worldX/4))-newX) && rRight <= ((centerX+(worldX/4))+newX)) { // EASTERN QUADRANT
        if (r->getCenterY() >= centerY && rTop <= ((centerY+(worldY/4))+newY) && rBottom >= ((centerY+(worldY/4))-newY)) {// NE
            if (tree->spcSon[tree->NE] == NULL)
                tree->spcSon[tree->NE] = new cNode();
            insertcNodeRectangle(r,tree->getNE(),worldX/2,worldY/2, centerX+(worldX/4),centerY+(worldY/4),4*(position)+2,p);
        } else if (r->getCenterY() <= centerY && rTop < ((centerY-(worldY/4))+newY) && rBottom > ((centerY-(worldY/4))-newY)) { // SE
            if (tree->spcSon[tree->SE] == NULL)
                tree->spcSon[tree->SE] = new cNode();
            insertcNodeRectangle(r,tree->getSE(),worldX/2,worldY/2,  centerX+(worldX/4),centerY-(worldY/4), 4*(position)+4,p);
        } else { // add here
            if (tree->binSon->length == 0)
                tree->binSon= new bNode(r);
            else
                tree->insert(r);
             if(trace == true)
            	cout << endl;
            return;
        }
    } else if (r->getCenterX() <= centerX && rLeft > ((centerX-(worldX/4))-newX) && rRight < ((centerX-(worldX/4))+newX)) {
        if(r->getCenterY() >= centerY && rTop < ((centerY+(worldY/4))+newY) && rBottom >= ((centerY+(worldY/4))-newY)) { 	// NW
            if (tree->spcSon[tree->NW] == NULL)
                tree->spcSon[tree->NW] = new cNode();
            insertcNodeRectangle(r,tree->getNW(),worldX/2,worldY/2, centerX-(worldX/4),centerY+(worldY/4), 4*(position)+1,p);
        } else if (r->getCenterY() <= centerY && rTop < ((centerY-(worldY/4))+newY) && rBottom > ((centerY-(worldY/4))-newY)) { // SW
            if (tree->spcSon[tree->SW] == NULL)
            	tree->spcSon[tree->SW] = new cNode();
            insertcNodeRectangle(r,tree->getSW(),worldX/2,worldY/2, centerX-(worldX/4),centerY-(worldY/4),4*(position)+3,p);
        } else { // add here            
            if (tree->binSon->length == 0)
                tree->binSon= new bNode(r);
            else
                tree->insert(r);
            if(trace == true)
            	cout << endl;
            return;
        }
    } else {// add here
            if (tree->binSon->length == 0)
                tree->binSon= new bNode(r);
            else
                tree->insert(r);
            if(trace == true)
            	cout << endl;
            return;
    }
}
void cNode::deletePoint(cNode **quadTreeNode,int findX, int findY, int cx, int cy, int lx, int ly, int position, bNode ** list) {
    int newX=0;
    int newY=0;
    int quadrant = 0;
    if((*quadTreeNode) != NULL) {
        if (trace == true)
            cout << position << " ";
        if ((*quadTreeNode)->binSon != NULL && (*quadTreeNode)->binSon->length > 0) {
            for(int i=0; i<(*quadTreeNode)->binSon->length; i++) {
                Rectangle * nodeToDelete = (*quadTreeNode)->binSon->getNode(i);
                if ((*quadTreeNode)->binSon->length == 1) {
                    (*quadTreeNode)->binSon = new bNode();
                } else {
                    (*quadTreeNode)->binSon->removeNode(nodeToDelete);
                }
                if ((*list)->length == 0)
                    (*list) = new bNode(nodeToDelete);
                else
                    (*list)->insertNode(nodeToDelete);
            }
        }
        if (findX < cx) {
            if (findY< cy) {
                newX = cx-(lx/4);
                newY = cy-(ly/4);
                quadrant = SW;
                deletePoint(&(*quadTreeNode)->spcSon[SW], findX, findY, newX,newY,lx/2,ly/2, 4*position+1,&(*list));
            } else {
                newX = cx-(lx/4);
                newY = cy+(ly/4);
                quadrant =NW;
                deletePoint(&(*quadTreeNode)->spcSon[NW], findX, findY, newX,newY,lx/2,ly/2,4*position+3,&(*list));
            }
        } else {
            if(findY< cy) {
                newX = cx+(lx/4);
                newY = cy-(ly/4);
                quadrant = SE;
                deletePoint(&(*quadTreeNode)->spcSon[SE], findX, findY,newX,newY,lx/2,ly/2,4*position+2,&(*list));
            } else {
                newX = cx+(lx/4);
                newY = cy+(ly/4);
                quadrant = NE;
                deletePoint(&(*quadTreeNode)->spcSon[NE], findX, findY ,newX,newY,lx/2,ly/2,4*position+4,&(*list));
            }
        }
        if ((*quadTreeNode)->spcSon[NW] == NULL && (*quadTreeNode)->spcSon[NE] == NULL && (*quadTreeNode)->spcSon[SW] == NULL && (*quadTreeNode)->spcSon[SE] == NULL && ((*quadTreeNode)->binSon == NULL || (*quadTreeNode)->binSon->length == 0) && (*quadTreeNode)!=this) {
            (*quadTreeNode) = NULL;
        }
    }
}

void cNode::regionNodeSearch(cNode **quadTreeNode, Rectangle * rect, int cx, int cy, int lx, int ly, int position, bNode ** list) {
    int newX=0;
    int newY=0;
    int quadrant = 0;
    if((*quadTreeNode) != NULL) {
        if (trace == true)
            cout << position << " ";
        
        if ((*quadTreeNode)->binSon != NULL && (*quadTreeNode)->binSon->length > 0) {
            for(int i=0; i<(*quadTreeNode)->binSon->length; i++) {
            	Rectangle * s = (*quadTreeNode)->binSon->getNode(i);
			        	
				int SRectMaxX = s->getCenterX()+(s->getLengthX()/2);
				int SRectMinX = s->getCenterX()-(s->getLengthX()/2);
				int SRectMaxY = s->getCenterY()+(s->getLengthY()/2);
				int SRectMinY = s->getCenterY()-(s->getLengthY()/2);
				
				int RRectMaxX = rect->getCenterX()+(rect->getLengthX()/2);
				int RRectMinX = rect->getCenterX()-(rect->getLengthX()/2);
				int RRectMaxY = rect->getCenterY()+(rect->getLengthY()/2);
				int RRectMinY = rect->getCenterY()-(rect->getLengthY()/2);

				bool contains = false;
				if (((RRectMinX <= SRectMinX) && (SRectMinX <= RRectMaxX)) && ((RRectMinY <= SRectMinY) && (SRectMinY <= RRectMaxY))){
					contains = true;
					//cout << s->getName() << " OVERLAPS WITH " << r->getName() << endl;
				}
					
				else if (((SRectMinX <= RRectMinX) && (RRectMinX <= SRectMaxX)) && ((SRectMinY <= RRectMinY) && (RRectMinY <= SRectMaxY))){
					contains = true;
					//cout << s->getName() << " OVERLAPS WITH " << r->getName()<< endl;
				}
					
				else if (((RRectMaxX >= SRectMaxX) && (SRectMaxX>= RRectMinX)) && ((RRectMaxY >= SRectMaxY) && (SRectMaxY>= RRectMinY))){
					contains = true;
					//cout << s->getName() << " OVERLAPS WITH " << r->getName()<< endl;
				}
					
				else if (((SRectMaxX >= RRectMaxX) && (RRectMaxX>= SRectMinX)) && ((SRectMaxY >= RRectMaxY) && (RRectMaxY>= SRectMinY))){
					contains = true;
							//cout << s->getName() << " OVERLAPS WITH " << r->getName()<< endl;		
				}
				if (contains == true){
					if ((*list)->length == 0)
					(*list) = new bNode(rect);
					else
					(*list)->insertNode(rect);
				}
            }
        }
        if (rect->getCenterX() < cx) {
            if (rect->getCenterY() < cy) {
                newX = cx-(lx/4);
                newY = cy-(ly/4);
                quadrant = SW;
                regionNodeSearch(&(*quadTreeNode)->spcSon[SW], rect, newX,newY,lx/2,ly/2, 4*position+1,&(*list));
            } else {
                newX = cx-(lx/4);
                newY = cy+(ly/4);
                quadrant =NW;
                regionNodeSearch(&(*quadTreeNode)->spcSon[NW], rect, newX,newY,lx/2,ly/2,4*position+3,&(*list));
            }
        } else {
            if(rect->getCenterY() < cy) {
                newX = cx+(lx/4);
                newY = cy-(ly/4);
                quadrant = SE;
                regionNodeSearch(&(*quadTreeNode)->spcSon[SE], rect,newX,newY,lx/2,ly/2,4*position+2,&(*list));
            } else {
                newX = cx+(lx/4);
                newY = cy+(ly/4);
                quadrant = NE;
                regionNodeSearch(&(*quadTreeNode)->spcSon[NE], rect,newX,newY,lx/2,ly/2,4*position+4,&(*list));
            }
        }
        if ((*quadTreeNode)->spcSon[NW] == NULL && (*quadTreeNode)->spcSon[NE] == NULL && (*quadTreeNode)->spcSon[SW] == NULL && (*quadTreeNode)->spcSon[SE] == NULL && ((*quadTreeNode)->binSon == NULL || (*quadTreeNode)->binSon->length == 0) && (*quadTreeNode)!=this) {
            (*quadTreeNode) = NULL;
        }
    }
}

cNode* cNode::getNW() {
    return spcSon[NW];
}
cNode* cNode::getSW() {
    return spcSon[SW];
}
cNode* cNode::getNE() {
    return spcSon[NE];
}
cNode* cNode::getSE() {
    return spcSon[SE];
}
cNode::~cNode() {}
