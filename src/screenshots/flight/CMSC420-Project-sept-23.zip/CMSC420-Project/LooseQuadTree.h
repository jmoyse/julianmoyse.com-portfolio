#ifndef LOOSEQUADTREE_H
#define LOOSEQUADTREE_H

#include <string>

#ifndef RECTANGLE_H
#include "Rectangle.h"
#endif

#include "Rectangle.h"
#ifndef CNODE_H
#include "cNode.h"
#endif

using namespace std;
class LooseQuadTree{
	public:	
		LooseQuadTree();
		LooseQuadTree(string name, int centerX, int centerY, int lengthX, int lengthY, float p);
		void AddRectangle(Rectangle *r);
		void insertNode(Rectangle *r, cNode *tree, int worldX, int worldY, int centerX, int centerY, int position);
		void traceOn();
		void traceOff();
		bNode * deletePoint(int x, int y);
		bNode * searchPoint(int x, int y);
		bNode * regionSearch(string n);
		
		void searchPoint(int findX, int findY, cNode *tree, int worldX, int worldY, int CenterX, int CenterY, int position, bNode ** list);

		Rectangle* findNodeTree(string name);
		void removeNode(Rectangle* rect, cNode **tree, int worldX, int worldY, int CenterX, int CenterY, int position, bNode ** list);
		void debug(string message);
		
		void ListBSTNodes();
		cNode *looseQuadRoot;
		Rectangle World;
		float p;

		~LooseQuadTree();
private:
	bool trace;


};
#endif
